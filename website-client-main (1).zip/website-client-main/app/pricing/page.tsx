import { title } from "@/components/primitives";

export default function PricingPage() {
	return (
		<div>
			<h1 className={title()}>Qrpage</h1>
		</div>
	);
}
